import java.util.*;
public class Main {
  public static void main(String[] args) {
    int[] arr = {2,3,4,5,6};
    System.out.println("Before Swapping: "+Arrays.toString(arr));
    swap(arr,0,1);
    System.out.println("After Swapping: "+Arrays.toString(arr));

    
  }

  static void swap(int[] array,int index1,int index2){
    int temp;
    temp = array[index1];
    array[index1] = array[index2];
    array[index2] = temp;
  }
}


// NOTICE :In Java, the static keyword in a method declaration means that the method belongs to the class itself rather than to instances of the class. It allows you to call the method directly through the class name without needing to create an instance of the class.