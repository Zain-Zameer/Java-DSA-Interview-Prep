
public class Main {
  public static void main(String[] args) {
    int[][] array = {
      {1,5},
      {7,3},
      {3,5}
    };

    System.out.println(RCW(array));
  }
  static int RCW(int[][] array){
    if(array.length==0){
      return -1;
    }
    int temp=0;
    for(int i =0;i<array.length;i++){
      for(int j =0;j<array[i].length;j++){
        temp+=array[i][j];
      }
      array[i][0]=temp;
      temp=0;
    }
    int max = 0;
    for(int i =0;i<array.length;i++){
      for(int j =0;j<array[i].length;j++){
        if(max<array[i][j]){
          max= array[i][j];
          
        }
      }
    }
    return max;
  }
}