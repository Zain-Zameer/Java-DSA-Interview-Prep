import java.util.Arrays;
public class Main {
  public static void main(String[] args) {
    String[] array = {"Pakistan","India","USA","Dubai","Saudia Arab"};
    String target = "SauDia ARAb";
    
    System.out.println(linearSearch(array,target));
  }

  static int linearSearch(String[] array,String target){
    if(array.length==0){
      return -1;
    }
    
    for(int i = 0;i<array.length;i++){
        
      if(target.toLowerCase().equals(array[i].toLowerCase())){
          
          return i;
        }
    }
    
    return -1;
    
  }
}