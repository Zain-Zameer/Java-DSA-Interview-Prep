import java.util.Arrays;
public class Main {
  public static void main(String[] args) {
    int[][] array = {
      {1,2,3},
      {4,5,6},
      {7,8,9}
    };
    int target = 8;
    System.out.println(linearSearch(array,target));
  }

  static String linearSearch(int[][] array,int target){
    int[] Answer = {-1,-1};
    
    if(array.length==0){
      return Arrays.toString(Answer);
    }
    
    for(int i = 0; i<array.length;i++){
      for(int j = 0;j<array[i].length;j++){
        if(target==array[i][j]){
          Answer[0] = i;
          Answer[1] = j;
          return Arrays.toString(Answer);
        }
      }
    }
    return Arrays.toString(Answer);
  }
}