
public class Main {
  public static void main(String[] args) {
    String name= "Muhammad Zain";
    char target = 'x';
    System.out.println(linearSearch(name,target));
  }

  static boolean linearSearch(String name,char target){
    if(name.length()==0){
      return false;
    }
    for(char c:name.toCharArray()){
      if(c==target){
        return true;
      }
    }
    return false;
  }
}