// FIND MINIMUM NUMBER
public class Main {
  public static void main(String[] args) {
    int[] array = {12,22,3,45,6};
    System.out.println(min(array));
  
  }
  
  static int min(int[] array){
    int min =array[0];
    for(int j:array){
      if(min>j){
        min = j;
      }
    }
    return min;
  }
}