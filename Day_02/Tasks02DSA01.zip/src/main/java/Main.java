import java.util.*;
public class Main {
  public static void main(String[] args) {
    int[] array = {22,33,4,6,3};
    System.out.println("Maximum Value in whole array: "+max(array));

    System.out.println("Maximum value in range: "+maxRange(array,2,4));

    reverse(array);
    System.out.println(Arrays.toString(array));
    
    
  }


  // Max value find in array 
  static int max(int[] array){
    int maxVal = 0;
    for(int i:array){
      if(maxVal<i){
        maxVal = i;
      }
    }
    return maxVal;
    
  }

  // Max range function
  static int maxRange(int[] array,int start,int end){
    int maxVal = 0;
    for(int i = start;i<=end;i++){
      if(maxVal<array[i]){
        maxVal = array[i];
      }
    }
    
    return maxVal;

  }

  // reverse an array function
  static void reverse(int[] array){
    int start = 0;
    int end = array.length-1;
    while(start<end){
      // swap
      swap(array,start,end);
      start++;
      end--;
    }
    
  }

  // swap function

  static void swap(int[] array,int start,int end){
    int temp = array[start];
    array[start] = array[end];
    array[end] = temp;
  }
}
