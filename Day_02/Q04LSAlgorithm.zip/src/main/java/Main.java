import java.util.*;
// Search in range
public class Main {
  public static void main(String[] args) {
    int[] array = {1,2,3,4,5,6,7,8,9,10};
    int target = 6;
    System.out.println(linearSearch(array,target,3,6));
  }

  // This what i know
  static int linearSearch(int[] array,int target,int start,int end){
    if(array.length==0){
      return -1;
    }
    for(int i = start;i<=end;i++){
      if(target==array[i]){
        return i;
      }
    }
    return -1;
  }
}