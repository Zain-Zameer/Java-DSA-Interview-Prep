import java.util.*;
public class Main {
  public static void main(String[] args) {

    // Array lists are mutable in java 
    // ArrayList<String> cars = new ArrayList<String>();

    // Adding items to array list
    // cars.add("Marko");
    // cars.add("Jiago");

    // CHECK METHOD 
    // System.out.println(cars.contains("Jiagoo"));

      // System.out.println(cars);

    // removing item in array list by name
    // cars.remove("Jiago");
    // removing item in array list by index
    // cars.remove(1);

    // System.out.println(cars);

    // get method to access the item by index
// System.out.println(cars.get(0));

    // set method to set the item by index,name of item
    // cars.set(0,"Hularo");
    // System.out.println(cars);

    // CLEAR METHOD IN ARRAY LIST
    // cars.clear();
    // System.out.println(cars);

    // size method in array list
    // System.out.println(cars.size());

    // using for each loop in array list
    // for(String i:cars){
    //   System.out.println(i);
    // }

    // NOW FOR ADDING MIXED DATATYPES IN ARRAY LIST
    // ArrayList<Object> arr = new ArrayList<Object>();
    // arr.add("Muhammad Zain");
    // arr.add(16121);
    // arr.add(45.6);
    // System.out.println(arr);

    // Multi dimensional arrayList in java

    ArrayList<ArrayList<Integer>> arr = new ArrayList<>();

    // Initialization
    for(int i = 0;i<3;i++){
      arr.add(new ArrayList<>());
    }

    // Taking input
    Scanner scan = new Scanner(System.in);
    for(int i = 0;i<3;i++){
      for(int j = 0;j<3;j++){
        arr.get(i).add(scan.nextInt());
      }
    }

    System.out.println(arr);
    
    
  }


}