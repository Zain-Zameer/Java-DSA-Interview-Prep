import java.util.*;

public class Main {
 public static void main(String args[]){
  //  Scanner scan = new Scanner(System.in);
  //  //  This is also how we can take input from user
  //  int a = scan.nextInt();
  //  int b = scan.nextInt();
  //  int c = scan.nextInt();
  // System.out.println(a+b+c);


   
   //syntax of arrays
   // datatype[] variableName = new datatype[size];


   // ARRAY OF PRIMITIVES
   // Declaration of array
   // int[] rollNo = new int[5];

   // initialization of array
   // int[] codes = {1,2,3,4,4};

   // for(int i =0;i<codes.length;i++){
   //   System.out.println(codes[i]);

   // going through the indices using for-each loop
   // for(int val : codes){
   //   System.out.println(val);
   // }

   //printing array directly we can use toString method 
   // System.out.println(Arrays.toString(codes));


    // ARRAY OF NON-PRIMITIVES
   // String[] arr = {"a","b","c"};


   // 2D Arrays

   //Declaration
   // int[][] arr= new int[3][3];

   //Initialization
   // int[][] arr = {
   //   {1,2,3},
   //   {4,5,6},
   //   {7,8,9}
   // };

   // for(int i = 0;i<arr.length;i++){
   //   for(int j = 0;j<arr[i].length;j++){
   //     System.out.print(arr[i][j]+" ");
   //   }
   //   System.out.print("\n");
   // }

   // Taking input in 2D array
   // Scanner scan = new Scanner(System.in);
   // int[][] arr= new int[3][2];
   // for(int i = 0;i<arr.length;i++){
   //   for(int j = 0;j<arr[i].length;j++){
   //     arr[i][j] = scan.nextInt();
   //   }
   // }
  
   // for(int i = 0;i<arr.length;i++){
   //    for(int j = 0;j<arr[i].length;j++){
   //      System.out.print(arr[i][j]+" ");
   //    }
   //   System.out.print("\n");
   //  }

   // We can also use the toString method to output the 2D array
   // System.out.println(Arrays.toString(arr[row]));

   // using for each loop for printing the 2D array
   // int[][] arr = {
   //    {1,2,3},
   //    {4,5,6},
   //    {7,8,9}
   //  };
   //  for(int[] a:arr){
   //    System.out.println(Arrays.toString(a));
   //  }

   
 }
}
