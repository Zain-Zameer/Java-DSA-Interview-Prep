
public class Main {
  public static void main(String[] args) {
    int[] array = {12,345,2,6,796};

    System.out.println(evenDigits(array));
  
  }

  static int evenDigits(int[] array){
    int evenDigits = 0;
    if(array.length==0){
      return -1;
    }
    for(int i:array){
      String temp;
      temp = String.valueOf(i);
      if(temp.length()%2==0){
        evenDigits+=1;
      }
    }
    return evenDigits;
  }
}