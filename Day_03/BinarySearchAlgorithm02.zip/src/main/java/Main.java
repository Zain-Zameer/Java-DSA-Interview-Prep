// ORDER AGNOSTIC BINARY SEARCH

public class Main {
  public static void main(String[] args) {
    int[] array = {10,9,8,7,6,5,4,3,2,1};
    int target = 10;

    System.out.println(binarySearch(array,target));
  }

  static int binarySearch(int[] array,int target){
    int start = 0;
    int end = array.length -1;

    // ascending checking
    if(array[start] <array[end]){
      while(start<=end){
        int mid = start+(end-start) /2;
        if(target>array[mid]){
          start=mid+1;
        }
        else if(target<array[mid]){
          end=mid-1;
        }
        else{
          return mid;
        }
      }
    }// else descending
    else{
      while(start<=end){
        int mid = start+(end-start) /2;
        if(target>array[mid]){
          end = mid-1;
        }
        else if(target<array[mid]){
          start = mid+1;
        }
        else{
          return mid;
        }
      }
    }
    return -1;
  }
}