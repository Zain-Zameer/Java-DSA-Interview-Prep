
public class Main {
  public static void main(String[] args) {
    int[] array = {2,4,6,8,10,12,14,16,18,20};
    int target = 4;

    System.out.println(binarySearch(array,target));
  }

  static int binarySearch(int[] array,int target){
    int start = 0;
    int end = array.length -1;

    while(start<=end){
      //find the middle element
      // int mid = (start+ end)/2;  might be possible that the start +end exceeds the range of integer in java

      //better way to find mid
      int mid = start+(end-start)/2;

      if(target<array[mid]){
        end = mid-1;
        
      }else if(target>array[mid]){
        start = mid+1;
      }
      else{
        return mid;
      }
      
      
    }
    return -1;
  }
}