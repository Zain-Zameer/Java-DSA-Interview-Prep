// Find First and Last Position of Element in Sorted Array
import java.util.Arrays;
public class Main {
  public static void main(String[] args) {
    int[] array = {5,7,7,8,8,10};
    int target = 8;
    System.out.print(binarySearch(array,target));
    
  }
  static int[] binarySearch(int[] array,int target){
    int[] answer = {-1,-1};
    int start = 0;
    int end = array.length-1;
    if(array.length==0){
      return answer;
    }
    while(start<=end){
      int mid = start+(end-start)/2;
      if(target<array[mid]){
        end = mid-1;
      }
      else if(target>array[mid]){
        start = mid+1;
      }
      else{
        answer[0] = mid;
        array[mid] = 0;
        for(int i =0;i<array.length;i++){
          if(target==array[i]){
            answer[0] = i;
          }
        }
        if(answer[0] == -1){
          answer[0]=start;
        }
        
        return answer;
      }
    }
    
    return answer;
  }
}