// FIND POSITON OF AN ELEMENT IN A SORTED ARRAY OF INFINITE NUMBERS
public class Main {
  public static void main(String[] args) {
    int[] array = {2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,30,55};
    int target = 10;
    System.out.println(findingRange(array,target));
    
  
  }
  static int findingRange(int array[],int target){
    // first find the range
    //first start with a box of size 2

    int start = 0;
    int end = 1;

    // condition for the target to lie in the range
    while(target>array[end]){
      int temp=end+1; // new start
      end=end+(end-start+1)*2;
      start = temp;
    }
    return binarySearch(array,target,start,end);
  }

  
  static int binarySearch(int[] array,int target,int start,int end){
      while(start<=end){
        int mid = start+(end-start) /2;
        if(target<array[mid]){
          end = mid - 1;
        }
        else if(target>array[mid]){
          start = mid+1;
        }
        else{
          return mid;
        }
      }
    return -1;
  }
}